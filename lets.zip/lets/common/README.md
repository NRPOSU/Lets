## RealistikOsu Shared Code
This is shared code between RealistikOsu's score server (lets) and Bancho (pep.py). It's essentially objects shared between multiple Python applications to keep objects consistent and not require 50 rewrites every time we change something.

## License
All code in this repository is licensed under the GNU AGPL 3 License.
See the "LICENSE" file for more information
