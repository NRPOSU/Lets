these are maintainer instructions, check the readme's in the binding
directories for user guides

# requirements
* swig
* docker
* twine (pip)

# building all bindings
```sh
./build.sh
```

# publishing all bindings
```sh
PUBLISH=1 ./build.sh
```
