#!/bin/sh

twine upload dist/*
